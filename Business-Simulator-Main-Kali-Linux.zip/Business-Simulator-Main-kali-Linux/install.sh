#!/bin/sh
# ============================================================
#  Business Simulator - Kali Linux Launcher
#  Version: Ultra Pro Max Edition
#  Website: https://issu321.github.io/Large-Scale-Company-Management-Dashboard/
#  POSIX sh compatible | Works with sh, bash, dash
# ============================================================

APP_NAME="Business Simulator"
APP_VERSION="Ultra Pro Max v3.0"
APP_URL="https://issu321.github.io/Large-Scale-Company-Management-Dashboard/"

# --- ANSI Colors via tput (POSIX safe) ---
if command -v tput >/dev/null 2>&1; then
    RED=$(tput setaf 1)
    GREEN=$(tput setaf 2)
    YELLOW=$(tput setaf 3)
    BLUE=$(tput setaf 4)
    CYAN=$(tput setaf 6)
    MAGENTA=$(tput setaf 5)
    WHITE=$(tput setaf 7)
    BOLD=$(tput bold)
    RESET=$(tput sgr0)
else
    RED=""
    GREEN=""
    YELLOW=""
    BLUE=""
    CYAN=""
    MAGENTA=""
    WHITE=""
    BOLD=""
    RESET=""
fi

# --- Status Printers ---
info() {
    printf "%s[INFO]%s %s\n" "$BLUE" "$RESET" "$1"
}

success() {
    printf "%s[OK]%s %s\n" "$GREEN" "$RESET" "$1"
}

warn() {
    printf "%s[WARN]%s %s\n" "$YELLOW" "$RESET" "$1"
}

err() {
    printf "%s[ERR]%s %s\n" "$RED" "$RESET" "$1"
}

step() {
    printf "%s[+]%s %s\n" "$CYAN" "$RESET" "$1"
}

# --- String length without ${#var} (POSIX) ---
strlen() {
    printf "%s" "$1" | wc -c
}

# --- Center text ---
center() {
    TEXT="$1"
    WIDTH=62
    LEN=$(strlen "$TEXT")
    PAD=$(( (WIDTH - LEN) / 2 ))
    PAD_STR=""
    I=0
    while [ "$I" -lt "$PAD" ]; do
        PAD_STR="$PAD_STR "
        I=$(( I + 1 ))
    done
    printf "%s%s%s\n" "$PAD_STR" "$TEXT" ""
}

# --- Banner ---
print_banner() {
    printf "\n"
    printf "%s%s%s\n" "$CYAN" "     ____  _    _         _                 _                  " "$RESET"
    printf "%s%s%s\n" "$CYAN" "    |  _ \| |  | |       | |               | |                 " "$RESET"
    printf "%s%s%s\n" "$CYAN" "    | |_) | | _| |__  ___| |__   ___   ___ | | ___  _ __ ___   " "$RESET"
    printf "%s%s%s\n" "$CYAN" "    |  _ <| |/ / '_ \/ __| '_ \ / _ \ / _ \| |/ _ \| '_ \ _ \  " "$RESET"
    printf "%s%s%s\n" "$CYAN" "    | |_) |   <| | | \__ \ | | | (_) | (_) | | (_) | | | | | | " "$RESET"
    printf "%s%s%s\n" "$CYAN" "    |____/|_|\_\_| |_|___/_| |_|\___/ \___/|_|\___/|_| |_| |_| " "$RESET"
    printf "\n"
    center "$MAGENTA$BOLD$APP_NAME$RESET"
    center "$BLUE$APP_VERSION$RESET"
    center "$WHITE$APP_URL$RESET"
    printf "\n"
    center "$YELLOW[ Kali Linux Edition | Optimized & Hardened ]$RESET"
    printf "\n"
}

# --- Spinner for background tasks (POSIX) ---
spinner() {
    PID=$1
    MSG=$2
    SPIN_DASH="-"
    SPIN_BACKSLASH="\\"
    SPIN_PIPE="|"
    SPIN_SLASH="/"
    
    while kill -0 "$PID" 2>/dev/null; do
        printf "\r%s%s %s%s" "$YELLOW" "$MSG" "$SPIN_DASH" "$RESET"
        sleep 0.1
        printf "\r%s%s %s%s" "$YELLOW" "$MSG" "$SPIN_BACKSLASH" "$RESET"
        sleep 0.1
        printf "\r%s%s %s%s" "$YELLOW" "$MSG" "$SPIN_PIPE" "$RESET"
        sleep 0.1
        printf "\r%s%s %s%s" "$YELLOW" "$MSG" "$SPIN_SLASH" "$RESET"
        sleep 0.1
    done
    printf "\r%s%s %s%s\n" "$GREEN" "$MSG" "Done!" "$RESET"
}

# --- Check Python3 ---
check_python() {
    step "Checking system environment..."
    if ! command -v python3 >/dev/null 2>&1; then
        err "python3 is NOT installed on this Kali system!"
        info "Fix: sudo apt update && sudo apt install -y python3 python3-venv python3-pip"
        exit 1
    fi
    
    PY_VER=$(python3 --version 2>&1)
    success "Found: $PY_VER"
    
    if ! command -v pip3 >/dev/null 2>&1; then
        warn "pip3 not found. Installing..."
        sudo apt install -y python3-pip >/dev/null 2>&1
    fi
}

# --- Setup Virtual Environment ---
setup_venv() {
    VENV_DIR="venv"
    
    if [ -d "$VENV_DIR" ] && [ -f "$VENV_DIR/bin/python3" ]; then
        success "Virtual environment exists at ./$VENV_DIR"
    else
        step "Creating virtual environment..."
        rm -rf "$VENV_DIR" 2>/dev/null
        python3 -m venv "$VENV_DIR" >/dev/null 2>&1 &
        VENV_PID=$!
        spinner "$VENV_PID" "Creating venv"
        wait "$VENV_PID"
        VENV_STATUS=$?
        
        if [ "$VENV_STATUS" -eq 0 ] && [ -f "$VENV_DIR/bin/python3" ]; then
            success "Virtual environment created"
        else
            err "Failed to create virtual environment"
            exit 1
        fi
    fi
}

# --- Install Requirements ---
install_deps() {
    VENV_PYTHON="$PWD/venv/bin/python3"
    VENV_PIP="$PWD/venv/bin/pip"
    
    if [ ! -f "requirements.txt" ]; then
        warn "requirements.txt not found! Skipping pip install."
        return
    fi
    
    step "Upgrading pip..."
    "$VENV_PYTHON" -m pip install --upgrade pip >/dev/null 2>&1 &
    PIP_PID=$!
    spinner "$PIP_PID" "Upgrading pip"
    wait "$PIP_PID"
    
    step "Installing dependencies..."
    "$VENV_PYTHON" -m pip install -r requirements.txt >/dev/null 2>&1 &
    INST_PID=$!
    spinner "$INST_PID" "Installing requirements"
    wait "$INST_PID"
    INST_STATUS=$?
    
    if [ "$INST_STATUS" -eq 0 ]; then
        success "All dependencies installed"
    else
        warn "Some packages may have failed (check output above)"
    fi
}

# --- Pre-flight Checks ---
preflight() {
    step "Running pre-flight checks..."
    
    if [ ! -f "app.py" ]; then
        err "app.py not found in current directory!"
        err "Please run this script from your project root."
        exit 1
    fi
    
    success "app.py found"
}

# --- Launch Application ---
launch() {
    VENV_PYTHON="$PWD/venv/bin/python3"
    
    printf "\n"
    printf "%s%s%s\n" "$GREEN$BOLD" "    >>> LAUNCHING $APP_NAME <<<" "$RESET"
    printf "%s%s%s\n" "$WHITE" "    Press CTRL+C to stop the server" "$RESET"
    printf "\n"
    
    "$VENV_PYTHON" app.py
}

# --- Cleanup on exit ---
cleanup() {
    printf "\n%s%s%s\n" "$YELLOW" "    [ Shutdown signal received ]" "$RESET"
    exit 0
}

trap cleanup INT TERM

# --- Main Execution ---
main() {
    print_banner
    check_python
    preflight
    setup_venv
    install_deps
    launch
}

main