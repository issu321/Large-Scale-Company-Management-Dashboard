from database.db import db
from datetime import datetime
from sqlalchemy import event

class Company(db.Model):
    __tablename__ = 'companies'

    id = db.Column(db.Integer, primary_key=True)
    company_name = db.Column(db.String(200), nullable=False)
    business_name = db.Column(db.String(200), nullable=False)
    owner_name = db.Column(db.String(200), nullable=False)
    ceo_name = db.Column(db.String(200), nullable=False)
    industry = db.Column(db.String(100))
    business_type = db.Column(db.String(50))
    description = db.Column(db.Text)
    company_size = db.Column(db.String(20))
    employee_count = db.Column(db.Integer, default=0)
    customer_count = db.Column(db.Integer, default=0)
    annual_revenue = db.Column(db.Float, default=0.0)
    total_equity = db.Column(db.Float, default=0.0)
    total_debt = db.Column(db.Float, default=0.0)
    currency = db.Column(db.String(10), default='USD')
    country = db.Column(db.String(100))
    city = db.Column(db.String(100))
    timezone = db.Column(db.String(100), default='UTC')
    tax_type = db.Column(db.String(50))
    tax_rate = db.Column(db.Float, default=0.0)
    logo_path = db.Column(db.String(255))
    website = db.Column(db.String(255))
    email = db.Column(db.String(120))
    mobile = db.Column(db.String(50))
    whatsapp = db.Column(db.String(50))
    telegram = db.Column(db.String(50))
    founded_date = db.Column(db.Date)
    registration_number = db.Column(db.String(100))
    health_score = db.Column(db.Float, default=75.0)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # ─── PAYMENT RELATIONSHIP ───
    payments = db.relationship(
        'CompanyPayments',
        backref='company',
        uselist=False,
        cascade='all, delete-orphan',
        lazy='joined'
    )

    def to_dict(self):
        return {
            'id': self.id,
            'company_name': self.company_name,
            'business_name': self.business_name,
            'owner_name': self.owner_name,
            'ceo_name': self.ceo_name,
            'industry': self.industry,
            'business_type': self.business_type,
            'company_size': self.company_size,
            'employee_count': self.employee_count,
            'customer_count': getattr(self, 'customer_count', 0),
            'annual_revenue': self.annual_revenue,
            'total_equity': getattr(self, 'total_equity', 0.0),
            'total_debt': getattr(self, 'total_debt', 0.0),
            'currency': self.currency,
            'country': self.country,
            'city': self.city,
            'timezone': self.timezone,
            'health_score': self.health_score,
            'logo_path': self.logo_path
        }


# ─── AUTO-CREATE PAYMENT RECORD FOR EVERY NEW COMPANY ───
@event.listens_for(Company, 'after_insert')
def auto_create_company_payments(mapper, connection, target):
    """
    Automatically creates an empty CompanyPayments row whenever
    a new Company is registered. This ensures company.payments
    never returns None for new registrations.
    """
    from database.models.company_payments import CompanyPayments
    connection.execute(
        CompanyPayments.__table__.insert(),
        {'company_id': target.id}
    )