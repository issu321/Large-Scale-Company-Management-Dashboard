import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from database.db import db
from database.models.company import Company
from database.models.company_payments import CompanyPayments

app = create_app()

with app.app_context():
    companies = Company.query.all()
    created = 0
    
    for company in companies:
        # Use direct query to avoid relationship caching issues
        existing = CompanyPayments.query.filter_by(company_id=company.id).first()
        if not existing:
            payments = CompanyPayments(company_id=company.id)
            db.session.add(payments)
            created += 1
            print(f"Created payment record for Company {company.id}: {company.company_name}")
    
    if created > 0:
        db.session.commit()
        print(f"\nDone! Created {created} missing payment record(s).")
    else:
        print("All companies already have payment records. No changes needed.")
    
    # Verify
    print("\n--- Verification ---")
    for company in Company.query.all():
        p = CompanyPayments.query.filter_by(company_id=company.id).first()
        status = "OK" if p else "MISSING"
        print(f"Company {company.id}: {status}")