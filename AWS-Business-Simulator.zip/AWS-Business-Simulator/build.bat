@echo off
echo Installing Modules...
pip install Flask Flask-SQLAlchemy Flask-WTF Flask-Login Flask-Mail Flask-Caching WTForms SQLAlchemy Werkzeug Jinja2 MarkupSafe itsdangerous bcrypt PyJWT Pillow pandas numpy scikit-learn prophet plotly openpyxl xlsxwriter reportlab qrcode python-dateutil requests bleach python-dotenv APScheduler tablib
echo ==========================================
echo  BusinessSimulator EXE Builder
echo ==========================================
echo.

:: Must run from project root where package.json is
cd /d "%~dp0"

echo Working in: %cd%
echo.

:: Check Node.js
node --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js not found. Install from https://nodejs.org
    pause
    exit /b 1
)

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Install from https://python.org
    pause
    exit /b 1
)

:: Install npm packages
if not exist "node_modules" (
    echo Installing Node packages...
    call npm install
    if errorlevel 1 (
        echo ERROR: npm install failed
        pause
        exit /b 1
    )
)

:: Clean old builds
echo Cleaning old builds...
if exist dist rmdir /S /Q dist
if exist build rmdir /S /Q build

:: Build EXE
echo.
echo Building EXE... This takes 5-10 minutes.
echo.
call npx electron-builder --win

if errorlevel 1 (
    echo.
    echo ERROR: Build failed. Check error above.
    pause
    exit /b 1
)

echo.
echo ==========================================
echo  BUILD SUCCESS!
echo ==========================================
echo.
echo Your EXE files are in the DIST folder:
echo.
echo   dist\BusinessSimulator 1.0.0.exe          ^(portable - just run it^)
echo   dist\BusinessSimulator Setup 1.0.0.exe    ^(installer - installs like normal software^)
echo.
echo first run setup
echo run main app!!!
echo software By Mohammed Usman Github, issu321
echo.

:: ==========================================
::  NEW FEATURE: Auto Desktop Shortcuts
:: ==========================================
echo Creating Desktop Shortcuts...

call :CreateShortcut "%cd%\dist\BusinessSimulator 1.0.0.exe" "BusinessSimulator 1.0.0.lnk" "Business Simulator 1.0.0"
call :CreateShortcut "%cd%\dist\BusinessSimulator Setup 1.0.0.exe" "BusinessSimulator Setup 1.0.0.lnk" "Business Simulator Setup 1.0.0"

echo.
echo ==========================================
echo  DESKTOP SHORTCUTS CREATED!
echo ==========================================
echo.
echo first run setup
echo run main app!!!
echo software By Mohammed Usman Github, issu321
echo.
pause
goto :eof

:: ==========================================
::  Subroutine: CreateShortcut
::  Args: %1 = Target EXE path, %2 = Shortcut name, %3 = Description
:: ==========================================
:CreateShortcut
if not exist "%~1" (
    echo WARNING: "%~nx1" not found in dist folder.
    goto :eof
)

echo Creating shortcut for %~3...
set "VBS_TMP=%TEMP%\makeshortcut_%RANDOM%.vbs"
(
    echo Set WshShell = WScript.CreateObject("WScript.Shell"^)
    echo strDesktop = WshShell.SpecialFolders("Desktop"^)
    echo Set oLink = WshShell.CreateShortcut(strDesktop ^& "\%~2"^)
    echo oLink.TargetPath = "%~1"
    echo oLink.WorkingDirectory = "%~dp1"
    echo oLink.IconLocation = "%~1,0"
    echo oLink.Description = "%~3"
    echo oLink.Save
) > "%VBS_TMP%"

cscript //nologo "%VBS_TMP%" >nul 2>&1
if errorlevel 1 (
    echo WARNING: Failed to create %~3 shortcut.
) else (
    echo SUCCESS: %~3 shortcut created on Desktop ^(%USERPROFILE%\Desktop\%~2^)
)

del /f /q "%VBS_TMP%" >nul 2>&1
goto :eof