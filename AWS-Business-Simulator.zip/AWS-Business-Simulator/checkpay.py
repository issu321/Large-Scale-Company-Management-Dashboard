import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from database.models.company_payments import CompanyPayments
from database.models.company import Company

app = create_app()

with app.app_context():
    payments = CompanyPayments.query.all()
    print(f"Total payment records: {len(payments)}")
    
    for p in payments:
        print(f"Company {p.company_id}: UPI={p.upi_id}, Bank={p.bank_name}, Account={p.bank_account_number}")
    
    # Check company linkage
    company = Company.query.first()
    if company:
        print(f"\n--- Company Check ---")
        print(f"Company: {company.company_name} (ID: {company.id})")
        if company.payments:
            print(f"Payments found via relationship:")
            print(f"  UPI ID: {company.payments.upi_id}")
            print(f"  Bank Name: {company.payments.bank_name}")
            print(f"  Account: {company.payments.bank_account_number}")
            print(f"  IFSC: {company.payments.bank_ifsc}")
            print(f"  WhatsApp: {company.payments.whatsapp_business_link}")
        else:
            print("No payments linked to this company!")
            print("You need to create a CompanyPayments record for this company.")
    else:
        print("No company found in database!")