from flask import Blueprint, send_from_directory, abort, current_app
import os

uploads_bp = Blueprint('uploads', __name__)

@uploads_bp.route('/<path:filename>')
def uploaded_file(filename):
    """
    Serve uploaded files from the configured UPLOAD_FOLDER.
    Supports files in subdirectories like qr_codes/, pdfs/, etc.
    """
    # Get the upload folder from app config (set in app.py)
    upload_folder = current_app.config.get('UPLOAD_FOLDER')
    
    if not upload_folder:
        # Fallback to project_root/uploads if not configured
        upload_folder = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
            'uploads'
        )
    
    # Security: prevent directory traversal outside upload folder
    requested_path = os.path.join(upload_folder, filename)
    requested_path = os.path.abspath(requested_path)
    upload_folder_abs = os.path.abspath(upload_folder)
    
    if not requested_path.startswith(upload_folder_abs):
        abort(403)
    
    if not os.path.exists(requested_path):
        abort(404)
    
    # Serve the file from the uploads directory
    directory = os.path.dirname(requested_path)
    file = os.path.basename(requested_path)
    
    return send_from_directory(directory, file)