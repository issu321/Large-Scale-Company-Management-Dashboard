import os
from werkzeug.utils import secure_filename
from flask import Blueprint, render_template, request, jsonify, session, flash, redirect, url_for, current_app
from flask_login import login_required, current_user
from database.models.company import Company
from database.models.company_payments import CompanyPayments
from database.db import db
from datetime import datetime

payments_bp = Blueprint('payments', __name__)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'}

def _allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def _ensure_qr_dir():
    qr_dir = os.path.join(current_app.config.get('UPLOAD_FOLDER', 'uploads'), 'qr_codes')
    os.makedirs(qr_dir, exist_ok=True)
    return qr_dir

@payments_bp.route('/')
@login_required
def index():
    company_id = session.get('company_id')
    if not company_id:
        return redirect('/logout')
    
    company = Company.query.get(company_id)
    payments = CompanyPayments.query.filter_by(company_id=company_id).first()
    
    # Build absolute URL for QR code if it exists
    qr_url = None
    if payments and payments.qr_code_path:
        qr_filename = os.path.basename(payments.qr_code_path)
        qr_url = url_for('uploads.uploaded_file', filename=f'qr_codes/{qr_filename}')
    
    return render_template('payments/payments_overview.html', 
                         company=company, payments=payments, qr_url=qr_url)

@payments_bp.route('/api/details')
@login_required
def api_details():
    company_id = session.get('company_id')
    payments = CompanyPayments.query.filter_by(company_id=company_id).first()
    if payments:
        return jsonify(payments.to_dict())
    return jsonify({'error': 'No payment details found'}), 404

@payments_bp.route('/update', methods=['POST'])
@login_required
def update():
    company_id = session.get('company_id')
    if not company_id:
        flash('Session expired. Please log in again.', 'danger')
        return redirect(url_for('auth.login'))
    
    payments = CompanyPayments.query.filter_by(company_id=company_id).first()
    if not payments:
        payments = CompanyPayments(company_id=company_id)
        db.session.add(payments)
    
    # ─── HANDLE QR CODE UPLOAD ───
    if 'qr_code' in request.files:
        file = request.files['qr_code']
        if file and file.filename and _allowed_file(file.filename):
            qr_dir = _ensure_qr_dir()
            # Generate unique filename: qr_companyid_timestamp.ext
            ext = file.filename.rsplit('.', 1)[1].lower()
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = secure_filename(f"qr_{company_id}_{timestamp}.{ext}")
            filepath = os.path.join(qr_dir, filename)
            file.save(filepath)
            # Store relative path for portability
            payments.qr_code_path = f"uploads/qr_codes/{filename}"
            flash('QR Code uploaded successfully!', 'success')
        elif file and file.filename and not _allowed_file(file.filename):
            flash('Invalid file type. Allowed: PNG, JPG, JPEG, GIF, WEBP, SVG', 'danger')
    
    # ─── UPDATE ALL TEXT FIELDS ───
    field_map = [
        'upi_id', 'upi_link', 'bank_name', 'bank_account_number',
        'bank_ifsc', 'bank_transfer_details', 'payment_gateway_link',
        'payment_link', 'whatsapp_business_link', 'telegram_business_link',
        'stripe_key', 'paypal_link', 'razorpay_key'
    ]
    
    for field in field_map:
        value = request.form.get(field)
        if value is not None:
            setattr(payments, field, value.strip() if value.strip() else None)
    
    db.session.commit()
    flash('Payment configuration saved successfully!', 'success')
    return redirect(url_for('payments.index'))