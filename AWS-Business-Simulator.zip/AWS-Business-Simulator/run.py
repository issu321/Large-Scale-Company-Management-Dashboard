import os
import sys

def setup_desktop_paths():
    is_bundled = (
        os.environ.get('DESKTOP_MODE') == '1' or
        getattr(sys, 'frozen', False) or
        hasattr(sys, '_MEIPASS')
    )

    if is_bundled:
        app_data = os.path.join(os.environ.get('APPDATA', os.path.expanduser('~')), 'BusinessSimulator')
        os.makedirs(app_data, exist_ok=True)
        for folder in ['instance', 'uploads', 'uploads/pdfs', 'exports', 'documents', 'documents/reports', 'logs']:
            os.makedirs(os.path.join(app_data, folder), exist_ok=True)

        os.environ['BUSINESSSIMULATOR_APPDATA'] = app_data
        os.environ['BUSINESSSIMULATOR_DB_PATH'] = os.path.join(app_data, 'instance', 'business_simulator.db')
        os.environ['BUSINESSSIMULATOR_UPLOAD_FOLDER'] = os.path.join(app_data, 'uploads')
        os.environ['BUSINESSSIMULATOR_EXPORT_FOLDER'] = os.path.join(app_data, 'exports')
        os.environ['BUSINESSSIMULATOR_DOCUMENT_FOLDER'] = os.path.join(app_data, 'documents')
        os.environ['BUSINESSSIMULATOR_INSTANCE_FOLDER'] = os.path.join(app_data, 'instance')

        bundle_root = os.environ.get('ELECTRON_RESOURCES_PATH', os.path.dirname(os.path.abspath(__file__)))
        bundle_db = os.path.join(bundle_root, 'instance', 'business_simulator.db')
        user_db = os.path.join(app_data, 'instance', 'business_simulator.db')

        if not os.path.exists(user_db) and os.path.exists(bundle_db):
            import shutil
            shutil.copy(bundle_db, user_db)
            print(f"[Desktop] Copied database to: {user_db}")

        print(f"[Desktop] Using APPDATA: {app_data}")
        return True
    return False

setup_desktop_paths()

from app import app

if __name__ == '__main__':
    port = int(os.environ.get('FLASK_PORT', 5000))
    app.run(host='127.0.0.1', port=port, debug=False)
