"""
desktop_paths.py - Centralized path resolution for desktop/bundled mode.

When the app is bundled as an EXE (PyInstaller/Electron), current_app.root_path
points to a read-only directory (e.g., C:\Program Files\BusinessSimulator\resources\).
All file writes MUST go to %APPDATA%/BusinessSimulator/ which is writable.

This module provides helpers that:
1. Return APPDATA paths when bundled
2. Fall back to project root when running from source
"""
import os
import sys


def is_bundled():
    """Check if running as a bundled EXE."""
    return (
        os.environ.get('DESKTOP_MODE') == '1' or
        getattr(sys, 'frozen', False) or
        hasattr(sys, '_MEIPASS')
    )


def get_app_data_dir():
    """Return the base APPDATA directory for the app."""
    appdata = os.environ.get('BUSINESSSIMULATOR_APPDATA')
    if appdata:
        return appdata
    if sys.platform == 'win32':
        base = os.environ.get('APPDATA', os.path.expanduser('~'))
    else:
        base = os.path.expanduser('~')
    return os.path.join(base, 'BusinessSimulator')


def ensure_dir(path):
    """Ensure a directory exists."""
    os.makedirs(path, exist_ok=True)
    return path


def get_documents_folder():
    """Return the writable documents folder."""
    docs = os.environ.get('BUSINESSSIMULATOR_DOCUMENT_FOLDER')
    if docs:
        return ensure_dir(docs)
    return ensure_dir(os.path.join(get_app_data_dir(), 'documents'))


def get_reports_folder():
    """Return the writable reports folder."""
    reports = os.environ.get('BUSINESSSIMULATOR_REPORT_FOLDER')
    if reports:
        return ensure_dir(reports)
    return ensure_dir(os.path.join(get_documents_folder(), 'reports'))


def get_exports_folder():
    """Return the writable exports folder."""
    exports = os.environ.get('BUSINESSSIMULATOR_EXPORT_FOLDER')
    if exports:
        return ensure_dir(exports)
    return ensure_dir(os.path.join(get_documents_folder(), 'exports'))


def get_uploads_folder():
    """Return the writable uploads folder."""
    uploads = os.environ.get('BUSINESSSIMULATOR_UPLOAD_FOLDER')
    if uploads:
        return ensure_dir(uploads)
    return ensure_dir(os.path.join(get_app_data_dir(), 'uploads'))


def get_instance_folder():
    """Return the writable instance folder (for SQLite DB)."""
    instance = os.environ.get('BUSINESSSIMULATOR_INSTANCE_FOLDER')
    if instance:
        return ensure_dir(instance)
    return ensure_dir(os.path.join(get_app_data_dir(), 'instance'))


def get_db_path():
    """Return the writable database path."""
    db = os.environ.get('BUSINESSSIMULATOR_DB_PATH')
    if db:
        return db
    return os.path.join(get_instance_folder(), 'business_simulator.db')


def resolve_file_path(file_path):
    """
    Resolve a file path for reading.
    
    If the file exists as-is, return it.
    If not, try to find it in APPDATA.
    This is used for DOWNLOAD routes that need to locate generated files.
    """
    if not file_path:
        return None
    
    # If it's already an absolute path and exists, use it
    if os.path.isabs(file_path) and os.path.exists(file_path):
        return file_path
    
    # Try APPDATA locations
    appdata = get_app_data_dir()
    candidates = [
        os.path.join(appdata, file_path),
        os.path.join(get_reports_folder(), os.path.basename(file_path)),
        os.path.join(get_exports_folder(), os.path.basename(file_path)),
        os.path.join(get_documents_folder(), file_path),
        os.path.join(get_documents_folder(), 'reports', os.path.basename(file_path)),
        os.path.join(get_documents_folder(), 'exports', os.path.basename(file_path)),
    ]
    
    for candidate in candidates:
        if os.path.exists(candidate):
            return candidate
    
    # If nothing found, return the original path (will likely fail, but that's expected)
    return file_path