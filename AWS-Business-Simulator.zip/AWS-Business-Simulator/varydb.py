import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from database.models.company import Company

app = create_app()

with app.app_context():
    company = Company.query.first()
    if company:
        print(f"Company: {company.company_name}")
        print(f"Payments attribute exists: {hasattr(company, 'payments')}")
        if company.payments:
            print(f"UPI ID: {company.payments.upi_id}")
            print(f"Bank: {company.payments.bank_name}")
            print(f"Account: {company.payments.bank_account_number}")
            print(f"IFSC: {company.payments.bank_ifsc}")
        else:
            print("WARNING: payments relationship returned None")
    else:
        print("No company found")