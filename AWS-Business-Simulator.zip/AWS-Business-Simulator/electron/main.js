const { app, BrowserWindow, dialog, Tray, Menu } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const net = require('net');

let mainWindow;
let flaskProcess;
let tray;
let flaskPort = 0;

// Find a free port
function findFreePort(startPort) {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.listen(startPort, () => {
      const port = server.address().port;
      server.close(() => resolve(port));
    });
    server.on('error', () => {
      findFreePort(startPort + 1).then(resolve).catch(reject);
    });
  });
}

function getPythonPath() {
  const isDev = !app.isPackaged;
  if (isDev) {
    return 'python';
  }
  // In production, use bundled python or system python
  const bundledPython = path.join(process.resourcesPath, 'python', 'pythonw.exe');
  const fs = require('fs');
  if (fs.existsSync(bundledPython)) {
    return bundledPython;
  }
  return 'pythonw';
}

function getProjectPath() {
  const isDev = !app.isPackaged;
  if (isDev) {
    return path.join(__dirname, '..');
  }
  return process.resourcesPath;
}

async function startFlask() {
  flaskPort = await findFreePort(5000);
  const pythonPath = getPythonPath();
  const projectPath = getProjectPath();
  const runScript = path.join(projectPath, 'run.py');
  const appScript = path.join(projectPath, 'app.py');

  // Determine which script to run
  const fs = require('fs');
  let targetScript = fs.existsSync(runScript) ? runScript : appScript;

  console.log('Starting Flask on port:', flaskPort);
  console.log('Python:', pythonPath);
  console.log('Script:', targetScript);

  const env = {
    ...process.env,
    FLASK_PORT: String(flaskPort),
    FLASK_ENV: 'production',
    DESKTOP_MODE: '1',
    ELECTRON_RESOURCES_PATH: process.resourcesPath || projectPath
  };

  flaskProcess = spawn(pythonPath, [targetScript], {
    cwd: projectPath,
    env: env,
    windowsHide: true,
    detached: false
  });

  flaskProcess.stdout.on('data', (data) => {
    console.log('[Flask]', data.toString().trim());
  });

  flaskProcess.stderr.on('data', (data) => {
    console.error('[Flask Error]', data.toString().trim());
  });

  flaskProcess.on('close', (code) => {
    console.log('Flask process exited with code', code);
  });

  // Wait for Flask to be ready
  await waitForFlask(flaskPort);
}

function waitForFlask(port, timeout = 30000) {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    const check = () => {
      const req = net.createConnection({ port: port, host: '127.0.0.1' });
      req.on('connect', () => {
        req.end();
        resolve();
      });
      req.on('error', () => {
        if (Date.now() - startTime > timeout) {
          reject(new Error('Flask failed to start'));
        } else {
          setTimeout(check, 500);
        }
      });
    };
    setTimeout(check, 2000); // Give Flask 2 seconds to start
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1600,
    height: 900,
    minWidth: 1000,
    minHeight: 600,
    show: false,
    title: 'BusinessSimulator',
    icon: path.join(__dirname, 'icon.ico'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      webSecurity: false // Allow loading local resources
    }
  });

  // Load the Flask app
  const url = 'http://127.0.0.1:' + flaskPort;
  console.log('Loading URL:', url);
  mainWindow.loadURL(url);

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Handle downloads - save to user-selected location
  mainWindow.webContents.session.on('will-download', (event, item, webContents) => {
    event.preventDefault();
    const filename = item.getFilename();

    dialog.showSaveDialog(mainWindow, {
      defaultPath: filename,
      filters: [
        { name: 'All Files', extensions: ['*'] }
      ]
    }).then(result => {
      if (!result.canceled && result.filePath) {
        item.setSavePath(result.filePath);
        item.resume();
      }
    }).catch(err => {
      console.error('Download dialog error:', err);
    });
  });
}

function createTray() {
  const iconPath = path.join(__dirname, 'icon.ico');
  const fs = require('fs');

  if (!fs.existsSync(iconPath)) {
    console.log('Tray icon not found, skipping tray');
    return;
  }

  tray = new Tray(iconPath);
  const contextMenu = Menu.buildFromTemplate([
    { label: 'Show BusinessSimulator', click: () => { if (mainWindow) mainWindow.show(); } },
    { label: 'Quit', click: () => { app.quit(); } }
  ]);
  tray.setToolTip('BusinessSimulator');
  tray.setContextMenu(contextMenu);

  tray.on('click', () => {
    if (mainWindow) {
      if (mainWindow.isVisible()) {
        mainWindow.focus();
      } else {
        mainWindow.show();
      }
    }
  });
}

app.whenReady().then(async () => {
  try {
    await startFlask();
    createWindow();
    createTray();
  } catch (err) {
    console.error('Failed to start:', err);
    dialog.showErrorBox('Startup Error', 'Failed to start BusinessSimulator.\n' + err.message);
    app.quit();
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    if (flaskProcess) {
      flaskProcess.kill();
    }
    app.quit();
  }
});

app.on('quit', () => {
  if (flaskProcess) {
    flaskProcess.kill();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
