@echo off
cd /d "%~dp0"

if not exist "node_modules" (
    echo Installing Node packages...
    call npm install
)

echo Starting dev mode...
call npm start
