@echo off
echo ==========================================
echo  BusinessSimulator EXE Builder
echo ==========================================
echo.

:: Go to the project root (where this script is located)
cd /d "%~dp0"
cd ..

echo Working in: %cd%
echo.

:: Check Node.js
node --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js not found. Install from https://nodejs.org
    pause
    exit /b 1
)

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Install from https://python.org
    pause
    exit /b 1
)

:: Install npm packages if not already installed
if not exist "node_modules" (
    echo Installing Node packages...
    call npm install
    if errorlevel 1 (
        echo ERROR: npm install failed
        pause
        exit /b 1
    )
)

:: Clean old builds
echo Cleaning old builds...
if exist dist rmdir /S /Q dist
if exist build rmdir /S /Q build

:: Build EXE
echo.
echo Building EXE... This takes 5-10 minutes.
echo.
call npx electron-builder --win

if errorlevel 1 (
    echo.
    echo ERROR: Build failed. Check error above.
    pause
    exit /b 1
)

echo.
echo ==========================================
echo  BUILD SUCCESS!
echo ==========================================
echo.
echo Your EXE files are in the DIST folder:
echo.
echo   dist\BusinessSimulator.exe          (portable - just run it)
echo   dist\BusinessSimulator Setup.exe    (installer - installs like normal software)
echo.
pause
