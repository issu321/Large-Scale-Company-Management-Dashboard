@echo off
echo ==========================================
echo  BusinessSimulator - Dev Mode
echo ==========================================
echo.

:: Check Node.js
node --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js not found. Install from https://nodejs.org
    pause
    exit /b 1
)

:: Install npm packages if not already installed
if not exist "node_modules" (
    echo Installing Node packages...
    call npm install
)

echo Starting in development mode...
echo.
call npm start
