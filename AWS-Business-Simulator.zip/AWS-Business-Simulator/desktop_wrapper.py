"""
Desktop Wrapper for BusinessSimulator
Put this file in your project ROOT (same folder as app.py)
This makes your app work correctly inside the EXE.
"""
import os
import sys
import shutil
from pathlib import Path

def setup_desktop_paths():
    """Setup paths so the app works inside Electron EXE"""
    # Check if running inside Electron/bundled app
    is_bundled = (
        os.environ.get('DESKTOP_MODE') == '1' or
        hasattr(sys, '_MEIPASS') or
        getattr(sys, 'frozen', False)
    )

    if is_bundled:
        # Use APPDATA for writable files (database, uploads, exports)
        app_data = Path(os.environ.get('APPDATA', os.path.expanduser('~'))) / 'BusinessSimulator'
        app_data.mkdir(parents=True, exist_ok=True)

        # Create subfolders
        for folder in ['instance', 'uploads', 'uploads/pdfs', 'exports', 'documents', 'documents/reports']:
            (app_data / folder).mkdir(parents=True, exist_ok=True)

        # Copy database from bundle to writable location on first run
        bundle_root = Path(os.environ.get('ELECTRON_RESOURCES_PATH', Path(__file__).parent))
        bundle_db = bundle_root / 'instance' / 'business_simulator.db'
        user_db = app_data / 'instance' / 'business_simulator.db'

        if not user_db.exists() and bundle_db.exists():
            shutil.copy(bundle_db, user_db)
            print(f"[Desktop] Copied database to: {user_db}")

        # Set environment variables for your app to use
        os.environ['INSTANCE_PATH'] = str(app_data / 'instance')
        os.environ['UPLOAD_FOLDER'] = str(app_data / 'uploads')
        os.environ['EXPORT_FOLDER'] = str(app_data / 'exports')
        os.environ['DOCUMENT_FOLDER'] = str(app_data / 'documents')
        os.environ['DATABASE_URL'] = f"sqlite:///{app_data / 'instance' / 'business_simulator.db'}"

        print(f"[Desktop] Using APPDATA: {app_data}")
    else:
        # Development mode - use project folder
        project_root = Path(__file__).parent
        os.environ.setdefault('INSTANCE_PATH', str(project_root / 'instance'))
        os.environ.setdefault('UPLOAD_FOLDER', str(project_root / 'uploads'))
        os.environ.setdefault('EXPORT_FOLDER', str(project_root / 'exports'))
        os.environ.setdefault('DOCUMENT_FOLDER', str(project_root / 'documents'))

# Run setup when imported
setup_desktop_paths()
