import os
import sys
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import LoginManager, login_required, current_user
from dotenv import load_dotenv

# ============================================================
# DESKTOP MODE PATH SETUP - Must be FIRST
# ============================================================
def setup_desktop_paths():
    is_bundled = (
        os.environ.get('DESKTOP_MODE') == '1' or
        getattr(sys, 'frozen', False) or
        hasattr(sys, '_MEIPASS')
    )

    if is_bundled:
        app_data = os.path.join(os.environ.get('APPDATA', os.path.expanduser('~')), 'BusinessSimulator')
        os.makedirs(app_data, exist_ok=True)

        for folder in ['instance', 'uploads', 'uploads/pdfs', 'exports', 'documents', 'documents/reports', 'logs']:
            os.makedirs(os.path.join(app_data, folder), exist_ok=True)

        os.environ['BUSINESSSIMULATOR_APPDATA'] = app_data
        os.environ['BUSINESSSIMULATOR_DB_PATH'] = os.path.join(app_data, 'instance', 'business_simulator.db')
        os.environ['BUSINESSSIMULATOR_UPLOAD_FOLDER'] = os.path.join(app_data, 'uploads')
        os.environ['BUSINESSSIMULATOR_EXPORT_FOLDER'] = os.path.join(app_data, 'exports')
        os.environ['BUSINESSSIMULATOR_DOCUMENT_FOLDER'] = os.path.join(app_data, 'documents')
        os.environ['BUSINESSSIMULATOR_INSTANCE_FOLDER'] = os.path.join(app_data, 'instance')

        bundle_root = os.environ.get('ELECTRON_RESOURCES_PATH', os.path.dirname(os.path.abspath(__file__)))
        bundle_db = os.path.join(bundle_root, 'instance', 'business_simulator.db')
        user_db = os.path.join(app_data, 'instance', 'business_simulator.db')

        if not os.path.exists(user_db) and os.path.exists(bundle_db):
            import shutil
            shutil.copy(bundle_db, user_db)
            print(f"[Desktop] Copied database to: {user_db}")

        print(f"[Desktop] Using APPDATA: {app_data}")
        return True
    else:
        project_root = os.path.dirname(os.path.abspath(__file__))
        os.environ.setdefault('BUSINESSSIMULATOR_APPDATA', project_root)
        os.environ.setdefault('BUSINESSSIMULATOR_DB_PATH', os.path.join(project_root, 'instance', 'business_simulator.db'))
        os.environ.setdefault('BUSINESSSIMULATOR_UPLOAD_FOLDER', os.path.join(project_root, 'uploads'))
        os.environ.setdefault('BUSINESSSIMULATOR_EXPORT_FOLDER', os.path.join(project_root, 'exports'))
        os.environ.setdefault('BUSINESSSIMULATOR_DOCUMENT_FOLDER', os.path.join(project_root, 'documents'))
        os.environ.setdefault('BUSINESSSIMULATOR_INSTANCE_FOLDER', os.path.join(project_root, 'instance'))
        return False

IS_BUNDLED = setup_desktop_paths()

load_dotenv()

def create_app():
    app = Flask(__name__, 
                template_folder='templates',
                static_folder='static',
                instance_path=os.environ.get('BUSINESSSIMULATOR_INSTANCE_FOLDER', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'instance')),
                instance_relative_config=True)

    app.config.from_object('config.settings.Config')

    # Override critical paths for desktop mode
    if IS_BUNDLED:
        app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.environ['BUSINESSSIMULATOR_DB_PATH']}"
        app.config['UPLOAD_FOLDER'] = os.environ['BUSINESSSIMULATOR_UPLOAD_FOLDER']
        app.config['EXPORT_FOLDER'] = os.environ['BUSINESSSIMULATOR_EXPORT_FOLDER']
        app.config['DOCUMENT_FOLDER'] = os.environ['BUSINESSSIMULATOR_DOCUMENT_FOLDER']
        app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'businesssimulator-desktop-secret-key-2026')

    from database.db import db, init_db
    db.init_app(app)

    # ============================================================
    # IMPORT MODELS BEFORE create_all() SO ALL TABLES ARE BUILT
    # ============================================================
    with app.app_context():
        from database.models.app_config import AppConfig, GlobalState
        from database.models.user import User
        from database.models.company import Company
        from database.models.theme_preference import ThemePreference
        db.create_all()

    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'info'

    @login_manager.user_loader
    def load_user(user_id):
        from database.models.user import User
        return User.query.get(int(user_id))

    from config.constants import CURRENCY_SYMBOLS

    @app.template_filter('format_currency')
    def format_currency_filter(value, currency_code=None):
        if value is None:
            return '-'
        try:
            value = float(value)
        except (TypeError, ValueError):
            return str(value)

        if currency_code is None:
            currency_code = session.get('company_currency', 'USD')

        symbol = CURRENCY_SYMBOLS.get(currency_code, '$')

        if abs(value) >= 1000000000000:
            return f'{symbol}{value/1000000000000:.1f}T'
        elif abs(value) >= 1000000000:
            return f'{symbol}{value/1000000000:.1f}B'
        elif abs(value) >= 1000000:
            return f'{symbol}{value/1000000:.1f}M'
        elif abs(value) >= 1000:
            return f'{symbol}{value:,.0f}'
        else:
            return f'{symbol}{value:,.2f}'

    @app.context_processor
    def inject_currency():
        from database.models.company import Company
        company_id = session.get('company_id')
        currency = session.get('company_currency', 'USD')

        if company_id:
            try:
                company = Company.query.get(company_id)
                if company and company.currency:
                    currency = company.currency
                    session['company_currency'] = currency
            except Exception:
                pass

        symbol = CURRENCY_SYMBOLS.get(currency, '$')

        return {
            'company_currency': currency,
            'currency_symbol': symbol,
            'currency_name': currency
        }

    from routes.auth import auth_bp
    from routes.dashboard import dashboard_bp
    from routes.business_twin import business_twin_bp
    from routes.simulation import simulation_bp
    from routes.forecasting import forecasting_bp
    from routes.risk_engine import risk_engine_bp
    from routes.analytics import analytics_bp
    from routes.reports import reports_bp
    from routes.documents import documents_bp
    from routes.settings import settings_bp
    from routes.developer import developer_bp
    from routes.payments import payments_bp
    from routes.scenario_builder import scenario_bp
    from routes.market_intelligence import market_bp
    from routes.financial_modeling import financial_bp
    from routes.customer_simulator import customer_bp
    from routes.employee_simulator import employee_bp
    from routes.supply_chain_simulator import supply_chain_bp
    from routes.operations_simulator import operations_bp
    from routes.ai_insights import ai_insights_bp
    from routes.data_lake import data_lake_bp
    from routes.competition import competition_bp
    from routes.uploads import uploads_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(business_twin_bp, url_prefix='/business-twin')
    app.register_blueprint(simulation_bp, url_prefix='/simulation')
    app.register_blueprint(forecasting_bp, url_prefix='/forecasting')
    app.register_blueprint(risk_engine_bp, url_prefix='/risk')
    app.register_blueprint(analytics_bp, url_prefix='/analytics')
    app.register_blueprint(reports_bp, url_prefix='/reports')
    app.register_blueprint(documents_bp, url_prefix='/documents')
    app.register_blueprint(settings_bp, url_prefix='/settings')
    app.register_blueprint(developer_bp, url_prefix='/developer')
    app.register_blueprint(payments_bp, url_prefix='/payments')
    app.register_blueprint(scenario_bp, url_prefix='/scenario')
    app.register_blueprint(market_bp, url_prefix='/market')
    app.register_blueprint(financial_bp, url_prefix='/financial')
    app.register_blueprint(customer_bp, url_prefix='/customer')
    app.register_blueprint(employee_bp, url_prefix='/employee')
    app.register_blueprint(supply_chain_bp, url_prefix='/supply-chain')
    app.register_blueprint(operations_bp, url_prefix='/operations')
    app.register_blueprint(ai_insights_bp, url_prefix='/ai-insights')
    app.register_blueprint(data_lake_bp, url_prefix='/data-lake')
    app.register_blueprint(competition_bp, url_prefix='/competition')
    app.register_blueprint(uploads_bp, url_prefix='/uploads')

    @app.context_processor
    def inject_globals():
        from config.themes import THEMES
        theme_id = session.get('theme', app.config.get('DEFAULT_THEME', 'aurora_enterprise'))
        theme = THEMES.get(theme_id, THEMES['aurora_enterprise'])
        return {
            'app_version': app.config.get('APP_VERSION', '1.0.0'),
            'current_year': datetime.now().year,
            'theme': theme,
            'theme_id': theme_id,
            'all_themes': THEMES
        }

    @app.errorhandler(404)
    def not_found(error):
        return render_template('base.html', error='Page not found'), 404

    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return render_template('base.html', error='Internal server error'), 500

    @app.route('/health')
    def health():
        return jsonify({'status': 'healthy', 'timestamp': datetime.utcnow().isoformat()})

    return app

app = create_app()

if __name__ == '__main__':
    port = int(os.environ.get('FLASK_PORT', 5000))
    debug_mode = not IS_BUNDLED
    app.run(host='127.0.0.1', port=port, debug=debug_mode)